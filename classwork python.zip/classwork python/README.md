# Rainfall Data Explorer

A small, local-first rainfall dashboard built with Python's standard library. The browser interface provides rainfall charts, searchable records, input validation, CSV import, and CSV/JSON/Markdown/text exports. Records are stored in `data/rainfall.json`; the first launch seeds 46 sample readings.

## Run

From this folder, run:

```powershell
python app.py
```

Open [http://127.0.0.1:8765](http://127.0.0.1:8765) in your browser. Press `Ctrl+C` in the terminal to stop the server. No package installation is required. To use another port, set the `RAINFALL_PORT` environment variable before launching the app.

## CSV import format

The CSV header must include `date,location,rainfall_mm`; `notes` is optional. Dates use `YYYY-MM-DD`, rainfall values must be between 0 and 500 mm, and imports are rejected as a whole if any row is invalid. The maximum upload size is 1 MB / 1,000 data rows.

## Tests

```powershell
python -m unittest discover -s tests
```

If the saved JSON file is malformed, the server reports the problem and leaves the file untouched so it can be recovered instead of silently replacing user data.
