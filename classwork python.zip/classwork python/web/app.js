const notice = document.querySelector("#notice");
const recordsBody = document.querySelector("#records-body");
const emptyState = document.querySelector("#empty-state");
const chart = document.querySelector("#rainfall-chart");
const form = document.querySelector("#record-form");
const searchInput = document.querySelector("#search-input");
const monthFilter = document.querySelector("#month-filter");
let currentRecords = [];
let searchTimer;

function todayLocal() {
  const now = new Date();
  now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
  return now.toISOString().slice(0, 10);
}

function showNotice(message, isError = false) {
  notice.textContent = message;
  notice.classList.toggle("error", isError);
  notice.hidden = false;
  window.clearTimeout(showNotice.timer);
  showNotice.timer = window.setTimeout(() => { notice.hidden = true; }, 5500);
}

async function request(url, options) {
  const response = await fetch(url, options);
  let payload;
  try {
    payload = await response.json();
  } catch {
    throw new Error(`The server returned an unreadable response (${response.status}).`);
  }
  if (!response.ok) {
    const detail = Array.isArray(payload.details) ? ` ${payload.details.join(" ")}` : "";
    throw new Error(`${payload.error || "Request failed."}${detail}`);
  }
  return payload;
}

function activeQuery() {
  const params = new URLSearchParams();
  const search = searchInput.value.trim();
  if (search) params.set("search", search);
  if (monthFilter.value) params.set("month", monthFilter.value);
  return params.toString();
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[char]);
}

function intensityFor(value) {
  if (value === 0) return ["Dry", "dry"];
  if (value < 10) return ["Light", "light"];
  if (value < 30) return ["Moderate", "moderate"];
  if (value < 100) return ["Heavy", "heavy"];
  return ["Extreme", "extreme"];
}

function renderRecords(records) {
  recordsBody.replaceChildren();
  emptyState.hidden = records.length > 0;
  document.querySelector(".table-scroll").hidden = records.length === 0;
  for (const record of records) {
    const [intensity, className] = intensityFor(Number(record.rainfall_mm));
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${escapeHtml(record.date)}</td>
      <td>${escapeHtml(record.location)}</td>
      <td class="rainfall-cell">${Number(record.rainfall_mm).toFixed(1)} mm</td>
      <td><span class="intensity intensity-${className}">${intensity}</span></td>
      <td>${escapeHtml(record.notes || "—")}</td>
      <td><button class="delete-button" type="button" aria-label="Delete reading from ${escapeHtml(record.date)} at ${escapeHtml(record.location)}" data-id="${escapeHtml(record.id)}">×</button></td>`;
    recordsBody.append(row);
  }
}

function renderSummary(summary) {
  document.querySelector("#stat-count").textContent = summary.record_count;
  document.querySelector("#stat-total").textContent = `${Number(summary.total_mm).toFixed(1)} mm`;
  document.querySelector("#stat-average").textContent = `${Number(summary.average_mm).toFixed(1)} mm`;
  const wettest = summary.wettest_month;
  document.querySelector("#stat-wettest").textContent = wettest ? wettest.month : "—";
  document.querySelector("#stat-wettest-caption").textContent = wettest
    ? `${Number(wettest.total_mm).toFixed(1)} mm total`
    : "monthly rainfall total";
  drawChart(summary.monthly);
}

function drawChart(monthly) {
  const bounds = chart.getBoundingClientRect();
  if (!bounds.width || !bounds.height) return;
  const ratio = window.devicePixelRatio || 1;
  chart.width = Math.round(bounds.width * ratio);
  chart.height = Math.round(bounds.height * ratio);
  const context = chart.getContext("2d");
  context.scale(ratio, ratio);
  const width = bounds.width;
  const height = bounds.height;
  const left = 35, right = 8, top = 14, bottom = 27;
  const plotWidth = width - left - right;
  const plotHeight = height - top - bottom;
  const maximum = Math.max(10, ...monthly.map((item) => Number(item.total_mm)));
  const step = Math.pow(10, Math.floor(Math.log10(maximum)));
  const ceiling = Math.ceil(maximum / step) * step;
  const gridLines = 4;
  context.clearRect(0, 0, width, height);
  context.font = "10px 'DM Sans', sans-serif";
  context.textBaseline = "middle";
  context.textAlign = "right";
  for (let index = 0; index <= gridLines; index += 1) {
    const y = top + plotHeight * index / gridLines;
    const value = ceiling * (gridLines - index) / gridLines;
    context.strokeStyle = "#edf1ef";
    context.lineWidth = 1;
    context.beginPath();
    context.moveTo(left, y);
    context.lineTo(width - right, y);
    context.stroke();
    context.fillStyle = "#a0aaa8";
    context.fillText(Number.isInteger(value) ? String(value) : value.toFixed(1), left - 8, y);
  }
  const slot = plotWidth / monthly.length;
  const barWidth = Math.min(20, slot * .56);
  monthly.forEach((item, index) => {
    const value = Number(item.total_mm);
    const barHeight = value === 0 ? 0 : (value / ceiling) * plotHeight;
    const x = left + index * slot + (slot - barWidth) / 2;
    const y = top + plotHeight - barHeight;
    context.fillStyle = "#63aa8c";
    context.beginPath();
    context.roundRect(x, y, barWidth, Math.max(0, barHeight), [4, 4, 0, 0]);
    context.fill();
    context.fillStyle = "#8d9997";
    context.textAlign = "center";
    context.fillText(item.month, x + barWidth / 2, height - 10);
  });
}

async function refresh() {
  try {
    const query = activeQuery();
    const suffix = query ? `?${query}` : "";
    const [records, summary] = await Promise.all([
      request(`/api/records${suffix}`),
      request(`/api/summary${suffix}`),
    ]);
    currentRecords = records;
    renderRecords(records);
    renderSummary(summary);
  } catch (error) {
    showNotice(error.message, true);
  }
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const data = new FormData(form);
  const payload = {
    date: data.get("date"),
    location: data.get("location"),
    rainfall_mm: data.get("rainfall_mm"),
    notes: data.get("notes"),
  };
  try {
    await request("/api/records", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    form.reset();
    document.querySelector("#record-date").value = todayLocal();
    showNotice("Rainfall reading saved.");
    await refresh();
  } catch (error) {
    showNotice(error.message, true);
  }
});

recordsBody.addEventListener("click", async (event) => {
  const button = event.target.closest(".delete-button");
  if (!button) return;
  try {
    await request(`/api/records/${encodeURIComponent(button.dataset.id)}`, { method: "DELETE" });
    showNotice("Rainfall reading deleted.");
    await refresh();
  } catch (error) {
    showNotice(error.message, true);
  }
});

searchInput.addEventListener("input", () => {
  window.clearTimeout(searchTimer);
  searchTimer = window.setTimeout(refresh, 180);
});
monthFilter.addEventListener("change", refresh);
window.addEventListener("resize", () => drawChartFromRecords());

function drawChartFromRecords() {
  const totals = Array.from({ length: 12 }, (_, index) => ({
    month: new Intl.DateTimeFormat("en", { month: "short" }).format(new Date(2025, index, 1)),
    total_mm: 0,
    readings: 0,
    average_mm: 0,
  }));
  for (const record of currentRecords) {
    const month = Number(record.date.slice(5, 7)) - 1;
    totals[month].total_mm += Number(record.rainfall_mm);
    totals[month].readings += 1;
  }
  drawChart(totals);
}

document.querySelector("#export-button").addEventListener("click", () => {
  const params = new URLSearchParams(activeQuery());
  params.set("format", document.querySelector("#export-format").value);
  window.location.href = `/api/export?${params}`;
});

document.querySelector("#chart-download").addEventListener("click", () => {
  const link = document.createElement("a");
  link.download = "monthly-rainfall.png";
  link.href = chart.toDataURL("image/png");
  link.click();
});

document.querySelector("#csv-file").addEventListener("change", async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  if (file.size > 1_000_000) {
    showNotice("CSV file exceeds the 1 MB import limit.", true);
    event.target.value = "";
    return;
  }
  try {
    const csv = await file.text();
    const result = await request("/api/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ csv }),
    });
    showNotice(`Imported ${result.imported} rainfall reading${result.imported === 1 ? "" : "s"}.`);
    await refresh();
  } catch (error) {
    showNotice(error.message, true);
  } finally {
    event.target.value = "";
  }
});

document.querySelector("#record-date").value = todayLocal();
refresh();
