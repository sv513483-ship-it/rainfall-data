import csv
import json
import math
import os
import re
import tempfile
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional


DATA_DIR = Path(__file__).resolve().parent / "data"
DATA_FILE = DATA_DIR / "rainfall.json"
SAMPLE_FILE = DATA_DIR / "rainfall_sample.csv"
REPORT_FILE = DATA_DIR / "rainfall_summary.md"

MONTH_NAMES = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
]


@dataclass
class RainfallRecord:
    year: int
    month: int
    rainfall_mm: float
    location: str

    def as_table_row(self) -> list[str]:
        return [
            str(self.year),
            MONTH_NAMES[self.month - 1],
            f"{self.rainfall_mm:.1f}",
            self.location,
        ]


def ensure_data_dir() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def validate_record(year: int, month: int, rainfall: float, location: str) -> list[str]:
    errors = []
    if year < 1900 or year > 2100:
        errors.append("Year must be between 1900 and 2100.")
    if month < 1 or month > 12:
        errors.append("Month must be between 1 and 12.")
    if not math.isfinite(rainfall) or rainfall < 0 or rainfall > 2000:
        errors.append("Rainfall must be between 0 and 2000 mm.")
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9 .,&'-]{1,49}", location.strip()):
        errors.append("Location must contain 2-50 letters/numbers and valid punctuation.")
    return errors


def normalize_record(raw: dict) -> Optional[RainfallRecord]:
    if not isinstance(raw, dict):
        return None
    try:
        year = int(raw["year"])
        month = int(raw["month"])
        rainfall = float(raw["rainfall_mm"])
        location_value = raw["location"]
        if not isinstance(location_value, str):
            return None
        location = location_value.strip()
    except (KeyError, TypeError, ValueError):
        return None

    if validate_record(year, month, rainfall, location):
        return None
    return RainfallRecord(year, month, rainfall, location)


def load_records() -> list[RainfallRecord]:
    ensure_data_dir()
    if not DATA_FILE.exists():
        save_records(create_sample_records())
        return create_sample_records()

    try:
        with DATA_FILE.open("r", encoding="utf-8") as file:
            payload = json.load(file)
        if isinstance(payload, list):
            raw_records = payload
        elif isinstance(payload, dict) and isinstance(payload.get("records"), list):
            raw_records = payload["records"]
        else:
            print(
                "Warning: rainfall.json has an unexpected format. "
                "Starting with sample data; the file was left unchanged."
            )
            return create_sample_records()
        records = []
        rejected = 0
        for raw in raw_records:
            record = normalize_record(raw)
            if record:
                records.append(record)
            else:
                rejected += 1
        if rejected:
            print(f"Warning: skipped {rejected} invalid record(s) in rainfall.json.")
        return records
    except (json.JSONDecodeError, OSError) as error:
        print(
            f"Warning: storage could not be read ({error}). "
            "Starting with sample data; the file was left unchanged."
        )
        return create_sample_records()


def save_records(records: Iterable[RainfallRecord]) -> bool:
    temporary_path = None
    try:
        ensure_data_dir()
        payload = {"records": [asdict(record) for record in records]}
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=DATA_DIR,
            prefix=".rainfall-", suffix=".tmp", delete=False,
        ) as file:
            temporary_path = Path(file.name)
            json.dump(payload, file, indent=2)
        os.replace(temporary_path, DATA_FILE)
        return True
    except (OSError, TypeError, ValueError) as error:
        print(f"Error: could not save data: {error}")
        return False
    finally:
        if temporary_path is not None:
            try:
                temporary_path.unlink(missing_ok=True)
            except OSError:
                pass


def create_sample_records() -> list[RainfallRecord]:
    data = [
        (2024, 1, 82.4, "Riverside"),
        (2024, 2, 74.8, "Riverside"),
        (2024, 3, 96.2, "Riverside"),
        (2024, 4, 118.5, "Riverside"),
        (2024, 5, 143.7, "Riverside"),
        (2024, 6, 188.9, "Riverside"),
        (2024, 7, 216.3, "Riverside"),
        (2024, 8, 201.6, "Riverside"),
        (2024, 9, 157.2, "Riverside"),
        (2024, 10, 121.8, "Riverside"),
        (2024, 11, 89.3, "Riverside"),
        (2024, 12, 78.1, "Riverside"),
        (2025, 1, 68.5, "Riverside"),
        (2025, 2, 71.2, "Riverside"),
        (2025, 3, 104.6, "Riverside"),
        (2025, 4, 132.1, "Riverside"),
        (2025, 5, 151.8, "Riverside"),
        (2025, 6, 195.4, "Riverside"),
        (2025, 7, 227.9, "Riverside"),
        (2025, 8, 209.7, "Riverside"),
        (2025, 9, 169.5, "Riverside"),
        (2025, 10, 115.3, "Riverside"),
        (2025, 11, 92.7, "Riverside"),
        (2025, 12, 81.4, "Riverside"),
        (2025, 1, 55.0, "Northvale"),
        (2025, 2, 63.4, "Northvale"),
        (2025, 3, 88.6, "Northvale"),
        (2025, 4, 111.2, "Northvale"),
        (2025, 5, 128.5, "Northvale"),
        (2025, 6, 176.8, "Northvale"),
        (2025, 7, 203.1, "Northvale"),
        (2025, 8, 184.7, "Northvale"),
        (2025, 9, 142.9, "Northvale"),
        (2025, 10, 96.4, "Northvale"),
        (2025, 11, 73.8, "Northvale"),
        (2025, 12, 69.1, "Northvale"),
    ]
    return [RainfallRecord(year, month, rainfall, location) for year, month, rainfall, location in data]


def write_sample_csv(records: Iterable[RainfallRecord]) -> bool:
    ensure_data_dir()
    try:
        with SAMPLE_FILE.open("w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["year", "month", "rainfall_mm", "location"])
            for record in records:
                writer.writerow(asdict(record).values())
        return True
    except OSError as error:
        print(f"Error: could not write sample CSV: {error}")
        return False


def prompt_text(prompt: str) -> str:
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("  ! Input cannot be blank.")


def prompt_integer(prompt: str, minimum: int, maximum: int) -> int:
    while True:
        raw = input(prompt).strip()
        try:
            value = int(raw)
            if minimum <= value <= maximum:
                return value
            print(f"  ! Enter a whole number from {minimum} to {maximum}.")
        except ValueError:
            print("  ! Enter a numeric whole number.")


def prompt_float(prompt: str, minimum: float, maximum: float) -> float:
    while True:
        raw = input(prompt).strip()
        try:
            value = float(raw)
            if minimum <= value <= maximum:
                return value
            print(f"  ! Enter a number from {minimum} to {maximum}.")
        except ValueError:
            print("  ! Enter a valid number.")


def print_table(records: list[RainfallRecord]) -> None:
    if not records:
        print("\nNo records match.")
        return
    widths = [6, 10, 13, 22]
    headers = ["Year", "Month", "Rainfall (mm)", "Location"]
    print("\n" + " | ".join(h.ljust(w) for h, w in zip(headers, widths)))
    print("-+-".join("-" * w for w in widths))
    for record in records:
        cells = [str(record.year), MONTH_NAMES[record.month - 1][:10],
                 f"{record.rainfall_mm:.1f}", record.location[:22]]
        print(" | ".join(cell.ljust(w) for cell, w in zip(cells, widths)))
    print(f"\nShowing {len(records)} record(s).")


def add_record(records: list[RainfallRecord]) -> None:
    print("\nAdd rainfall record")
    year = prompt_integer("Year (1900-2100): ", 1900, 2100)
    month = prompt_integer("Month (1-12): ", 1, 12)
    rainfall = prompt_float("Rainfall in mm (0-2000): ", 0, 2000)
    location = prompt_text("Location: ")
    errors = validate_record(year, month, rainfall, location)
    if errors:
        for error in errors:
            print(f"  ! {error}")
        return
    new_record = RainfallRecord(year, month, rainfall, location.strip())
    updated_records = [*records, new_record]
    if save_records(updated_records):
        records.append(new_record)
        print("Record saved successfully.")


def search_records(records: list[RainfallRecord]) -> None:
    print("\nSearch records")
    print("1. Location")
    print("2. Year")
    print("3. Month")
    choice = prompt_integer("Choose filter: ", 1, 3)
    if choice == 1:
        keyword = prompt_text("Location keyword: ").lower()
        matches = [r for r in records if keyword in r.location.lower()]
    elif choice == 2:
        year = prompt_integer("Year: ", 1900, 2100)
        matches = [r for r in records if r.year == year]
    else:
        month = prompt_integer("Month (1-12): ", 1, 12)
        matches = [r for r in records if r.month == month]
    print_table(matches)


def summarize(records: list[RainfallRecord]) -> dict:
    if not records:
        return {"count": 0, "total": 0.0, "average": 0.0,
                "minimum": None, "maximum": None}
    values = [r.rainfall_mm for r in records]
    return {
        "count": len(records),
        "total": sum(values),
        "average": sum(values) / len(values),
        "minimum": min(records, key=lambda r: r.rainfall_mm),
        "maximum": max(records, key=lambda r: r.rainfall_mm),
    }


def print_summary(records: list[RainfallRecord]) -> dict:
    summary = summarize(records)
    print("\nRainfall Executive Summary")
    print("=" * 34)
    print(f"Records:       {summary['count']}")
    if summary["count"]:
        print(f"Total rainfall: {summary['total']:.1f} mm")
        print(f"Average:        {summary['average']:.1f} mm")
        print(f"Lowest:         {summary['minimum'].rainfall_mm:.1f} mm "
              f"({MONTH_NAMES[summary['minimum'].month - 1]} {summary['minimum'].year})")
        print(f"Highest:        {summary['maximum'].rainfall_mm:.1f} mm "
              f"({MONTH_NAMES[summary['maximum'].month - 1]} {summary['maximum'].year})")

        monthly = [0.0] * 12
        counts = [0] * 12
        for record in records:
            monthly[record.month - 1] += record.rainfall_mm
            counts[record.month - 1] += 1
        averages = [monthly[i] / counts[i] if counts[i] else 0.0 for i in range(12)]
        observed_months = [i for i, count in enumerate(counts) if count]
        wettest = max(observed_months, key=averages.__getitem__)
        driest = min(observed_months, key=averages.__getitem__)
        print(f"Wettest month:  {MONTH_NAMES[wettest]} ({averages[wettest]:.1f} mm avg)")
        print(f"Driest month:   {MONTH_NAMES[driest]} ({averages[driest]:.1f} mm avg)")
        if summary["maximum"].rainfall_mm >= 200:
            print("WARNING: Critical rainfall threshold (>= 200 mm) detected.")
    return summary


def plot_rainfall(records: list[RainfallRecord]) -> None:
    if not records:
        print("No records to plot.")
        return
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        print("Matplotlib is not installed. Run: pip install matplotlib")
        return

    locations = sorted({record.location for record in records})
    fig, (line_ax, bar_ax) = plt.subplots(1, 2, figsize=(13, 5))

    for location in locations:
        location_records = sorted(
            (r for r in records if r.location == location),
            key=lambda r: (r.year, r.month),
        )
        labels = [f"{MONTH_NAMES[r.month - 1][:3]} {r.year}" for r in location_records]
        values = [r.rainfall_mm for r in location_records]
        line_ax.plot(labels, values, marker="o", linewidth=2, label=location)
    line_ax.set_title("Monthly Rainfall Trend")
    line_ax.set_xlabel("Month")
    line_ax.set_ylabel("Rainfall (mm)")
    line_ax.tick_params(axis="x", rotation=45)
    line_ax.grid(alpha=0.25)
    line_ax.legend()

    monthly_totals = [0.0] * 12
    for record in records:
        monthly_totals[record.month - 1] += record.rainfall_mm
    bar_ax.bar(MONTH_NAMES, monthly_totals, color="steelblue")
    bar_ax.set_title("Rainfall Distribution by Month")
    bar_ax.set_ylabel("Total rainfall (mm)")
    bar_ax.tick_params(axis="x", rotation=45)
    bar_ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    chart_path = DATA_DIR / "rainfall_chart.png"
    fig.savefig(chart_path, dpi=150)
    plt.show()
    print(f"Chart saved to {chart_path}")


def export_reports(records: list[RainfallRecord]) -> None:
    ensure_data_dir()
    csv_path = DATA_DIR / "rainfall_report.csv"
    try:
        with csv_path.open("w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["year", "month", "rainfall_mm", "location"])
            writer.writerows([
                [record.year, record.month, record.rainfall_mm, record.location]
                for record in records
            ])
    except OSError as error:
        print(f"Error: could not export CSV: {error}")
        return

    summary = summarize(records)
    md = [
        "# Rainfall Data Explorer Report",
        "",
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        "",
        "## Executive Summary",
        "",
        f"- Record count: {summary['count']}",
    ]
    if summary["count"]:
        md += [
            f"- Total rainfall: {summary['total']:.1f} mm",
            f"- Average rainfall: {summary['average']:.1f} mm",
            f"- Minimum rainfall: {summary['minimum'].rainfall_mm:.1f} mm",
            f"- Maximum rainfall: {summary['maximum'].rainfall_mm:.1f} mm",
        ]
    md += ["", "## Records", "", "| Year | Month | Rainfall (mm) | Location |",
           "|---:|:---|---:|:---|"]
    md += [
        f"| {r.year} | {MONTH_NAMES[r.month - 1]} | {r.rainfall_mm:.1f} | {r.location} |"
        for r in records
    ]
    REPORT_FILE.write_text("\n".join(md), encoding="utf-8")
    print(f"CSV report saved to {csv_path}")
    print(f"Markdown report saved to {REPORT_FILE}")


def import_csv(records: list[RainfallRecord]) -> None:
    path_text = prompt_text("CSV file path: ")
    path = Path(path_text).expanduser()
    if not path.exists():
        print("Error: file does not exist.")
        return

    accepted_records = []
    rejected = 0
    required = {"year", "month", "rainfall_mm", "location"}
    try:
        with path.open("r", newline="", encoding="utf-8-sig") as file:
            reader = csv.DictReader(file)
            if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
                print("Error: CSV needs year, month, rainfall_mm, and location columns.")
                return
            for line_number, raw in enumerate(reader, start=2):
                record = normalize_record(raw)
                if record:
                    accepted_records.append(record)
                else:
                    rejected += 1
                    print(f"  ! Row {line_number}: invalid rainfall record.")
    except (OSError, csv.Error) as error:
        print(f"Error: could not read CSV: {error}")
        return

    if accepted_records and save_records([*records, *accepted_records]):
        records.extend(accepted_records)
        print(f"Imported {len(accepted_records)} record(s); rejected {rejected}.")
    elif accepted_records:
        print(f"Could not save imported records; current data is unchanged. Rejected {rejected}.")
    else:
        print(f"Imported 0 record(s); rejected {rejected}.")


def print_banner() -> None:
    print("\n" + "=" * 58)
    print("  RAINFALL DATA EXPLORER")
    print("  Environment & Sustainability | FutureReady Hack")
    print("=" * 58)


def print_menu() -> None:
    print("""
1. View all records
2. Add rainfall record
3. Search/filter records
4. Executive summary
5. Plot rainfall chart
6. Export CSV and Markdown reports
7. Import CSV dataset
8. Reset to sample dataset
9. Exit
""")


def main() -> None:
    records = load_records()
    ensure_data_dir()
    write_sample_csv(records)
    print_banner()

    while True:
        print_menu()
        choice = prompt_integer("Choose an option (1-9): ", 1, 9)
        if choice == 1:
            print_table(records)
        elif choice == 2:
            add_record(records)
        elif choice == 3:
            search_records(records)
        elif choice == 4:
            print_summary(records)
        elif choice == 5:
            plot_rainfall(records)
        elif choice == 6:
            export_reports(records)
        elif choice == 7:
            import_csv(records)
        elif choice == 8:
            records = create_sample_records()
            if save_records(records):
                write_sample_csv(records)
                print("Sample dataset restored.")
        else:
            print("Thank you for using Rainfall Data Explorer.")
            break


if __name__ == "__main__":
    main()
