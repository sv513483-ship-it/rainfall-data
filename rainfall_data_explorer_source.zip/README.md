# Rainfall Data Explorer

A beginner-friendly terminal application for recording, searching, analyzing, exporting, and visualizing rainfall data.

Requires Python 3.9 or later and Matplotlib 3.7 or later.

## Run

```powershell
py -m pip install -r requirements.txt
py rainfall_explorer.py
```

## Features

- Menu-driven terminal interface
- Defensive year, month, rainfall, and location validation
- 36-record Riverside/Northvale sample dataset
- JSON persistence in `data/rainfall.json`
- CSV and JSON-compatible local storage
- Location, year, and month search
- Totals, averages, extremes, and monthly trends
- Matplotlib line and bar charts
- CSV and Markdown report exports
- Bulk CSV imports with row-level error reporting

## CSV Import Format

```csv
year,month,rainfall_mm,location
2026,1,84.5,Riverside
```
