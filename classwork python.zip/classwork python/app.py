"""Local web application for exploring rainfall measurements."""

from __future__ import annotations

import csv
import io
import json
import math
import os
import sys
import tempfile
import uuid
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import RLock
from urllib.parse import parse_qs, urlparse


ROOT = Path(__file__).resolve().parent
WEB_DIR = ROOT / "web"
DATA_FILE = ROOT / "data" / "rainfall.json"
MAX_REQUEST_BYTES = 1_000_000
MAX_IMPORT_ROWS = 1_000
CSV_FIELDS = ("date", "location", "rainfall_mm", "notes")


class StoreError(Exception):
    """Raised when the local data file cannot safely be read or written."""


def seed_records() -> list[dict[str, object]]:
    monthly_readings = [
        [0.0, 4.2, 12.8, 2.6],
        [0.0, 1.4, 8.6, 3.1],
        [0.0, 5.2, 18.4, 7.3],
        [2.4, 16.8, 31.2, 8.1],
        [0.0, 22.5, 45.6, 13.4],
        [18.2, 54.3, 82.1, 36.7],
        [34.5, 76.2, 112.4, 58.8],
        [24.1, 68.5, 93.7, 42.6],
        [12.4, 38.1, 61.5, 25.3],
        [1.2, 14.8, 29.6, 8.7],
        [0.0, 6.3, 17.2],
        [0.0, 3.8, 9.4],
    ]
    locations = ("North Station", "Riverside", "Hilltop", "Central Park")
    records: list[dict[str, object]] = []
    for month, readings in enumerate(monthly_readings, start=1):
        for index, rainfall in enumerate(readings):
            records.append({
                "id": str(uuid.uuid4()),
                "date": date(2025, month, (5, 13, 21, 28)[index]).isoformat(),
                "location": locations[(month + index - 1) % len(locations)],
                "rainfall_mm": rainfall,
                "notes": "Sample observation",
            })
    return records


def validate_record(payload: object) -> dict[str, object]:
    if not isinstance(payload, dict):
        raise ValueError("Record must be a JSON object.")

    raw_date = payload.get("date")
    if not isinstance(raw_date, str):
        raise ValueError("Date is required.")
    try:
        parsed_date = date.fromisoformat(raw_date.strip())
    except ValueError as exc:
        raise ValueError("Date must be a valid YYYY-MM-DD date.") from exc
    if parsed_date.isoformat() != raw_date.strip():
        raise ValueError("Date must use the YYYY-MM-DD format.")

    location = payload.get("location")
    if not isinstance(location, str):
        raise ValueError("Location is required.")
    location = location.strip()
    if not location or len(location) > 60 or any(ord(char) < 32 for char in location):
        raise ValueError("Location must be 1–60 printable characters.")

    rainfall = payload.get("rainfall_mm")
    if isinstance(rainfall, bool):
        raise ValueError("Rainfall must be a number from 0 to 500 mm.")
    try:
        rainfall_value = float(rainfall)
    except (TypeError, ValueError) as exc:
        raise ValueError("Rainfall must be a number from 0 to 500 mm.") from exc
    if not math.isfinite(rainfall_value) or not 0 <= rainfall_value <= 500:
        raise ValueError("Rainfall must be a number from 0 to 500 mm.")

    notes = payload.get("notes", "")
    if not isinstance(notes, str) or len(notes.strip()) > 300:
        raise ValueError("Notes must be 300 characters or fewer.")

    return {
        "id": str(uuid.uuid4()),
        "date": parsed_date.isoformat(),
        "location": location,
        "rainfall_mm": round(rainfall_value, 2),
        "notes": notes.strip(),
    }


def summarize(records: list[dict[str, object]]) -> dict[str, object]:
    month_totals = [0.0] * 12
    month_counts = [0] * 12
    for record in records:
        month = date.fromisoformat(str(record["date"])).month - 1
        rainfall = float(record["rainfall_mm"])
        month_totals[month] += rainfall
        month_counts[month] += 1

    monthly = [
        {
            "month": date(2000, month + 1, 1).strftime("%b"),
            "total_mm": round(month_totals[month], 2),
            "average_mm": round(month_totals[month] / month_counts[month], 2)
            if month_counts[month]
            else 0,
            "readings": month_counts[month],
        }
        for month in range(12)
    ]
    wettest = max(monthly, key=lambda item: float(item["total_mm"]), default=None)
    total = sum(float(record["rainfall_mm"]) for record in records)
    return {
        "record_count": len(records),
        "total_mm": round(total, 2),
        "average_mm": round(total / len(records), 2) if records else 0,
        "wettest_month": wettest if records else None,
        "monthly": monthly,
    }


def parse_csv_import(text: str) -> tuple[list[dict[str, object]], list[str]]:
    reader = csv.DictReader(io.StringIO(text))
    headers = set(reader.fieldnames or [])
    required = {"date", "location", "rainfall_mm"}
    if not required.issubset(headers) or headers - set(CSV_FIELDS):
        return [], [
            "CSV headers must include date, location, rainfall_mm, and optionally notes."
        ]

    records: list[dict[str, object]] = []
    errors: list[str] = []
    for row_number, row in enumerate(reader, start=2):
        if row_number > MAX_IMPORT_ROWS + 1:
            errors.append(f"CSV exceeds the {MAX_IMPORT_ROWS}-row import limit.")
            break
        if not row or all(not (value or "").strip() for value in row.values()):
            continue
        try:
            records.append(validate_record(row))
        except ValueError as exc:
            errors.append(f"Row {row_number}: {exc}")
    if not records and not errors:
        errors.append("The CSV contains no data rows.")
    return ([], errors) if errors else (records, [])


class RecordStore:
    def __init__(self, path: Path):
        self.path = path
        self.lock = RLock()

    def load(self) -> list[dict[str, object]]:
        with self.lock:
            if not self.path.exists():
                records = seed_records()
                self.save(records)
                return records
            try:
                data = json.loads(self.path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                raise StoreError(
                    f"Could not read {self.path}: {exc}. The existing file was left unchanged."
                ) from exc
            if not isinstance(data, list):
                raise StoreError(f"{self.path} must contain a JSON array of records.")
            for record in data:
                if (
                    not isinstance(record, dict)
                    or not isinstance(record.get("id"), str)
                    or not isinstance(record.get("date"), str)
                    or not isinstance(record.get("location"), str)
                    or isinstance(record.get("rainfall_mm"), bool)
                    or not isinstance(record.get("rainfall_mm"), (int, float))
                    or not isinstance(record.get("notes"), str)
                ):
                    raise StoreError(f"{self.path} contains a record with an invalid schema.")
                try:
                    date.fromisoformat(record["date"])
                except ValueError as exc:
                    raise StoreError(f"{self.path} contains a record with an invalid date.") from exc
                if not math.isfinite(float(record["rainfall_mm"])):
                    raise StoreError(f"{self.path} contains a non-finite rainfall value.")
            return data

    def save(self, records: list[dict[str, object]]) -> None:
        with self.lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temp_name = None
            try:
                with tempfile.NamedTemporaryFile(
                    "w",
                    encoding="utf-8",
                    newline="\n",
                    dir=self.path.parent,
                    delete=False,
                ) as temp_file:
                    temp_name = temp_file.name
                    json.dump(records, temp_file, indent=2, ensure_ascii=False)
                    temp_file.write("\n")
                    temp_file.flush()
                    os.fsync(temp_file.fileno())
                os.replace(temp_name, self.path)
            except OSError as exc:
                if temp_name and os.path.exists(temp_name):
                    os.unlink(temp_name)
                raise StoreError(f"Could not save rainfall data to {self.path}: {exc}") from exc

    def add(self, additions: list[dict[str, object]]) -> None:
        with self.lock:
            records = self.load()
            records.extend(additions)
            self.save(records)

    def delete(self, record_id: str) -> bool:
        with self.lock:
            records = self.load()
            remaining = [record for record in records if record["id"] != record_id]
            if len(remaining) == len(records):
                return False
            self.save(remaining)
            return True


store = RecordStore(DATA_FILE)


def filter_records(records: list[dict[str, object]], query: dict[str, list[str]]) -> list[dict[str, object]]:
    search = query.get("search", [""])[0].strip().casefold()
    month_text = query.get("month", [""])[0]
    month = int(month_text) if month_text.isdigit() and 1 <= int(month_text) <= 12 else None
    filtered = []
    for record in records:
        if search and not any(
            search in str(record[key]).casefold() for key in ("date", "location", "notes")
        ):
            continue
        if month and date.fromisoformat(str(record["date"])).month != month:
            continue
        filtered.append(record)
    return sorted(filtered, key=lambda item: (str(item["date"]), str(item["location"])), reverse=True)


def csv_content(records: list[dict[str, object]]) -> str:
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=CSV_FIELDS, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(records)
    return output.getvalue()


def export_content(records: list[dict[str, object]], export_format: str) -> tuple[str, str, str]:
    report = summarize(records)
    if export_format == "csv":
        return csv_content(records), "text/csv; charset=utf-8", "rainfall-report.csv"
    if export_format == "json":
        return json.dumps(records, indent=2), "application/json; charset=utf-8", "rainfall-report.json"
    if export_format in ("markdown", "txt"):
        if export_format == "markdown":
            lines = [
                "# Rainfall Data Explorer — Summary",
                "",
                f"- Records: {report['record_count']}",
                f"- Total rainfall: {report['total_mm']} mm",
                f"- Average reading: {report['average_mm']} mm",
                "",
                "| Date | Location | Rainfall (mm) | Notes |",
                "| --- | --- | ---: | --- |",
            ]
            lines.extend(
                "| " + " | ".join(
                    str(record[field]).replace("|", "\\|")
                    for field in ("date", "location", "rainfall_mm", "notes")
                ) + " |"
                for record in records
            )
            mime = "text/markdown; charset=utf-8"
        else:
            lines = [
                "Rainfall Data Explorer — Summary",
                f"Records: {report['record_count']}",
                f"Total rainfall: {report['total_mm']} mm",
                f"Average reading: {report['average_mm']} mm",
                "",
                "Date       | Location       | Rainfall (mm) | Notes",
                "-----------|----------------|---------------|------",
            ]
            lines.extend(
                f"{str(record['date']):10} | {str(record['location']):14} | "
                f"{str(record['rainfall_mm']):13} | {record['notes']}"
                for record in records
            )
            mime = "text/plain; charset=utf-8"
        content = "\n".join(lines) + "\n"
        extension = "md" if export_format == "markdown" else "txt"
        return content, mime, f"rainfall-report.{extension}"
    raise ValueError("Format must be csv, json, markdown, or txt.")


class RainfallHandler(BaseHTTPRequestHandler):
    server_version = "RainfallExplorer/1.0"

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/":
            self.serve_static("index.html")
        elif parsed.path in ("/app.js", "/styles.css"):
            self.serve_static(parsed.path.lstrip("/"))
        elif parsed.path in ("/api/records", "/api/summary"):
            self.serve_api_data(parsed.path, parse_qs(parsed.query))
        elif parsed.path == "/api/export":
            self.serve_export(parse_qs(parsed.query))
        else:
            self.send_json(404, {"error": "Not found."})

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        try:
            payload = self.read_json_body()
            if parsed.path == "/api/records":
                record = validate_record(payload)
                store.add([record])
                self.send_json(201, record)
            elif parsed.path == "/api/import":
                if not isinstance(payload, dict) or not isinstance(payload.get("csv"), str):
                    raise ValueError("Provide CSV text in the 'csv' field.")
                imported, errors = parse_csv_import(payload["csv"])
                if errors:
                    self.send_json(400, {"error": "CSV import was not applied.", "details": errors})
                    return
                store.add(imported)
                self.send_json(201, {"imported": len(imported)})
            else:
                self.send_json(404, {"error": "Not found."})
        except ValueError as exc:
            self.send_json(400, {"error": str(exc)})
        except StoreError as exc:
            self.send_json(500, {"error": str(exc)})

    def do_DELETE(self) -> None:
        record_id = urlparse(self.path).path.removeprefix("/api/records/")
        if not record_id or "/" in record_id:
            self.send_json(404, {"error": "Record not found."})
            return
        try:
            if not store.delete(record_id):
                self.send_json(404, {"error": "Record not found."})
                return
            self.send_json(200, {"deleted": True})
        except StoreError as exc:
            self.send_json(500, {"error": str(exc)})

    def serve_api_data(self, path: str, query: dict[str, list[str]]) -> None:
        try:
            records = filter_records(store.load(), query)
            if path == "/api/records":
                self.send_json(200, records)
            else:
                self.send_json(200, summarize(records))
        except StoreError as exc:
            self.send_json(500, {"error": str(exc)})

    def serve_export(self, query: dict[str, list[str]]) -> None:
        export_format = query.get("format", ["csv"])[0]
        try:
            records = filter_records(store.load(), query)
            content, content_type, filename = export_content(records, export_format)
        except (StoreError, ValueError) as exc:
            self.send_json(400 if isinstance(exc, ValueError) else 500, {"error": str(exc)})
            return
        body = content.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(body)))
        self.send_common_headers()
        self.end_headers()
        self.wfile.write(body)

    def serve_static(self, filename: str) -> None:
        path = WEB_DIR / filename
        if not path.is_file():
            self.send_json(404, {"error": "Page asset not found."})
            return
        content_type = "text/html; charset=utf-8" if filename.endswith(".html") else (
            "application/javascript; charset=utf-8"
            if filename.endswith(".js")
            else "text/css; charset=utf-8"
        )
        body = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_common_headers()
        self.end_headers()
        self.wfile.write(body)

    def read_json_body(self) -> object:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("Invalid request length.") from exc
        if length < 0 or length > MAX_REQUEST_BYTES:
            raise ValueError("Request body exceeds the 1 MB limit.")
        try:
            return json.loads(self.rfile.read(length))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise ValueError("Request body must be valid JSON.") from exc

    def send_json(self, status: int, payload: object) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_common_headers()
        self.end_headers()
        self.wfile.write(body)

    def send_common_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")

    def log_message(self, format: str, *args: object) -> None:
        sys.stderr.write("%s - %s\n" % (self.address_string(), format % args))


def main() -> None:
    try:
        store.load()
    except StoreError as exc:
        print(f"Unable to start: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
    port = int(os.environ.get("RAINFALL_PORT", "8765"))
    server = ThreadingHTTPServer(("127.0.0.1", port), RainfallHandler)
    print(f"Rainfall Data Explorer is running at http://127.0.0.1:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping Rainfall Data Explorer.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
