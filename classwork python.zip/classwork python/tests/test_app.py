import tempfile
import unittest
from pathlib import Path

import app


class RainfallAppTests(unittest.TestCase):
    def test_validate_record_normalizes_input_and_rejects_out_of_range_values(self):
        record = app.validate_record({
            "date": "2025-08-03",
            "location": "  Riverside  ",
            "rainfall_mm": "12.35",
            "notes": "  morning reading ",
        })
        self.assertEqual(record["location"], "Riverside")
        self.assertEqual(record["rainfall_mm"], 12.35)
        self.assertEqual(record["notes"], "morning reading")
        for rainfall in (-0.1, 500.1, float("inf"), True):
            with self.subTest(rainfall=rainfall), self.assertRaises(ValueError):
                app.validate_record({
                    "date": "2025-08-03",
                    "location": "Riverside",
                    "rainfall_mm": rainfall,
                })

    def test_summary_aggregates_months_and_handles_empty_records(self):
        records = [
            {"date": "2025-06-02", "rainfall_mm": 4.5},
            {"date": "2025-06-03", "rainfall_mm": 5.5},
            {"date": "2025-07-02", "rainfall_mm": 12},
        ]
        summary = app.summarize(records)
        self.assertEqual(summary["record_count"], 3)
        self.assertEqual(summary["total_mm"], 22)
        self.assertEqual(summary["average_mm"], 7.33)
        self.assertEqual(summary["wettest_month"]["month"], "Jul")
        self.assertEqual(app.summarize([])["wettest_month"], None)

    def test_csv_import_is_all_or_nothing_for_invalid_rows(self):
        content = "date,location,rainfall_mm,notes\n2025-01-02,North,2.4,ok\n2025-01-03,South,999,bad\n"
        records, errors = app.parse_csv_import(content)
        self.assertEqual(records, [])
        self.assertTrue(any("Row 3" in error for error in errors))

    def test_csv_import_accepts_valid_rows_and_exports_markdown_table(self):
        records, errors = app.parse_csv_import(
            "date,location,rainfall_mm\n2025-01-02,North,2.4\n"
        )
        self.assertEqual(errors, [])
        self.assertEqual(records[0]["notes"], "")
        markdown, content_type, _ = app.export_content(records, "markdown")
        self.assertEqual(content_type, "text/markdown; charset=utf-8")
        self.assertIn("| 2025-01-02 | North | 2.4 |  |", markdown)

    def test_store_seeds_sample_data_only_when_missing(self):
        with tempfile.TemporaryDirectory() as directory:
            store = app.RecordStore(Path(directory) / "rainfall.json")
            records = store.load()
            self.assertEqual(len(records), 46)
            self.assertEqual(len(store.load()), 46)

    def test_store_does_not_replace_malformed_existing_data(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "rainfall.json"
            path.write_text("{invalid", encoding="utf-8")
            with self.assertRaises(app.StoreError):
                app.RecordStore(path).load()
            self.assertEqual(path.read_text(encoding="utf-8"), "{invalid")


if __name__ == "__main__":
    unittest.main()
