import unittest

import rainfall_explorer as app


class RainfallExplorerTests(unittest.TestCase):
    def test_sample_dataset_size_and_validity(self):
        records = app.create_sample_records()
        self.assertEqual(len(records), 36)
        self.assertTrue(all(not app.validate_record(r.year, r.month, r.rainfall_mm, r.location)
                            for r in records))

    def test_validation_rejects_invalid_boundaries(self):
        self.assertTrue(app.validate_record(1800, 13, -1, ""))
        self.assertEqual(app.validate_record(2025, 12, 2000, "Riverside"), [])

    def test_summary_metrics(self):
        records = [
            app.RainfallRecord(2025, 1, 10.0, "A"),
            app.RainfallRecord(2025, 2, 30.0, "A"),
        ]
        summary = app.summarize(records)
        self.assertEqual(summary["count"], 2)
        self.assertEqual(summary["total"], 40.0)
        self.assertEqual(summary["average"], 20.0)
        self.assertEqual(summary["minimum"].rainfall_mm, 10.0)
        self.assertEqual(summary["maximum"].rainfall_mm, 30.0)

    def test_empty_summary(self):
        summary = app.summarize([])
        self.assertEqual(summary["count"], 0)
        self.assertEqual(summary["average"], 0.0)


if __name__ == "__main__":
    unittest.main()
